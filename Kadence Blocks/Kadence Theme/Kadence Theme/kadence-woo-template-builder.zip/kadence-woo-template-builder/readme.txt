=== Kadence WooCommerce SiteOrigin Builder ===
Contributors: Kadence WP
Tags: 
Requires at least: 4.4
Tested up to: 5.4.0
Stable tag: 1.1.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Page builder for woocommerce. This plugin adds templates to create custom product, archive and checkout pages using Page Builder by SiteOrigin.

== Description ==

Page builder for woocommerce. This plugin adds templates to create custom product, archive and checkout pages using Page Builder by SiteOrigin.

== Installation ==

Install the plugin into the `/wp-content/plugins/` folder, and activate it.


== Changelog ==

= 1.1.7 =
* Update: Template change to prevent WPML from overriding.

= 1.1.6 =
* Update: API

= 1.1.5 =
* Update: API

= 1.1.4 =
* Fix: Taxonomy meta conflict.

= 1.1.3 =
* Add: WPML Config file.

= 1.1.2 =
* Fix: Update issue.

= 1.1.1 =
* Add: archive description widget.

= 1.1.0 =
* Fix: Bug causing endless loop.

= 1.0.9 =
* Update: Sale with single product gallery.
* Add: Schema
* Add: option to enable category above product title.

= 1.0.8 =
* Update: remove extra query from front end.

= 1.0.7 =
* Update: woo 3.3 support

= 1.0.6 =
* Update: css output.

= 1.0.5 =
* Update: Prebuilt Layouts.

= 1.0.4 =
* Add: Prebuilt Layouts.

= 1.0.3 =
* Fix: Use woo extras gallery if active.

= 1.0.2 =
* Fix Update Issue.

= 1.0.1 =
* Add prebuilt product page.

= 1.0.0 =
* Initial Version.
