=== Kadence Related Content ===
Contributors: Kadence WP
Tags: 
Requires at least: 4.4
Tested up to: 5.5.0
Stable tag: 1.0.10
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A powerful plugin to add "inter content marketing" throughout a site by linking posts, products and pages together to create better interlinking throughout your site.

== Description ==

A powerful plugin to add "inter content marketing" throughout a site by linking posts, products and pages together to create better interlinking throughout your site.

== Installation ==

Install the plugin into the `/wp-content/plugins/` folder, and activate it.


== Changelog ==

= 1.0.10 =
* Fix: RTL issue.

= 1.0.9 =
* Fix: Issue with WC rating.

= 1.0.8 =
* Add: Events and Portfolio posts to options.

= 1.0.7 =
* Update: Performance Improvements JS Loading.
* Update: Better Kadence Theme support.

= 1.0.6 =
* Fix: Updater, php notice.

= 1.0.5 =
* Update: Issue with Virtue Update

= 1.0.4 =
* Update: CMB
* Fix: Issue with memebership endless loop.

= 1.0.3 =
* Update: updater
* Update: image resizer

= 1.0.2 =
* Update: typos.

= 1.0.1 =
* Fix conflict issue.

= 1.0 =
* Initial Version.
