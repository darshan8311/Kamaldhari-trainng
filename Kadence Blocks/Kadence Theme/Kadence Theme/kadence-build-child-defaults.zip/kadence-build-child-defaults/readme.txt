=== Kadence Child Theme Builder ===
Contributors: britner
Tags: templates, gutenberg
Requires at least: 5.3
Tested up to: 5.8
Stable tag: 1.0.5
Requires PHP: 7.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easily create a child theme with custom theme defaults and a custom starter template.

== Description ==
Easily create a child theme with custom theme defaults and a custom starter template.

== Changelog ==

= 1.0.5 =
* Add: Theme Slug (Folder Name) Option.
* Fix: Issue with version number.

= 1.0.4 =
* Add: New Settings for cloud library
* Update: Build Process

= 1.0.3 =
* Update: Better Child Stylesheet Creation.
* Update: Sanitize for single quotes in html areas.

= 1.0.2 =
* Fix: better support for any repo plugin.

= 1.0.1 =
* Update Plugin name.

= 1.0.0 =
* release