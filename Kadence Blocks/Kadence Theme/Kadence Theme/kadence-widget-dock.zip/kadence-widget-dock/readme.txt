=== Kadence Widget Dock ===
Contributors: Kadence WP
Tags: 
Requires at least: 4.9
Tested up to: 5.6.0
Stable tag: 1.0.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A simple Widget Dock that slides out to promote anything placed in the widget area.

== Description ==

A simple Widget Dock that slides out to promote anything placed in the widget area.

== Installation ==

Install the plugin into the `/wp-content/plugins/` folder, and activate it.


== Changelog ==

= 1.0.6 =
* Fix: WP 5.6 issue.

= 1.0.5 =
* Fix: PHP 7.4 issue.

= 1.0.4 =
* Fix: Js Version Number

= 1.0.3 =
* Fix: Cookie Time

= 1.0.2 =
* Safari Bug.

= 1.0.1 =
* Lets keep wordfence happy.

= 1.0.0 =
* Initial Version.
