=== Kadence Simple Share ===
Contributors: Kadence WP
Tags: 
Requires at least: 4.4
Tested up to: 5.4.3
Stable tag: 1.2.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Simple plugin for sharing posts on social networks

== Description ==

Simple plugin for sharing posts on social networks

== Installation ==

Install the plugin into the `/wp-content/plugins/` folder, and activate it.


== Changelog ==

= 1.2.4 | 29th June 2020 =
* Add: WhatsApp.

= 1.2.3 | 27th March 2020 =
* Add: Xing.
* Remove: Google+
* Update: JS, no need for jQuery.
* Update: Meta, move to sidebar.
* Update: Tooltip, css only solution.
* Add: No JS method, links open new tab instead of window.

= 1.2.2 | 16th April 2018 =
* Add: Excerpt sharing icons.

= 1.2.1 | 16th March 2018 =
* Fix: Issue with membership endless loop.
* Update: Simplify Meta

= 1.2.0 | 4th January 2018 =
* Add: Pinterest
* Add: Reddit
* Update: Font add woff2

= 1.1.0 | 4th January 2017 =
* Add: Page by page meta box to turn off social icons.
* Add: Support for non Kadence Themes

= 1.0.0 =
* Initial Version.
